const userData = require("./users");
const userFunctions = require("./userFunctions");

module.exports = {
  users : userData,
  userFunctions : userFunctions
};